"""Validated receipt storage, extraction, and transactional persistence."""

from __future__ import annotations

import logging
import warnings
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from uuid import UUID, uuid4

from PIL import Image
from PIL import UnidentifiedImageError
from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from ..models import ChaseEvent, ClarificationReceipt, ClarificationRequest
from ..schemas.clarification_receipt import (
    ClarificationReceiptResponse,
    ReceiptExtraction,
    ReceiptExtractionResult,
)
from .invoice_service import ALLOWED_FORMATS, MAX_UPLOAD_SIZE
from .receipt_extraction_service import (
    ReceiptExtractionError,
    ReceiptExtractionNotConfiguredError,
    ReceiptProvider,
)

logger = logging.getLogger(__name__)
RECEIPT_DIRECTORY = Path(__file__).resolve().parents[3] / "data" / "receipts"
MEDIA_TYPES = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png"}


class ClarificationReceiptNotFoundError(Exception):
    """Raised when no clarification request exists for the supplied ID."""


class ReceiptImageValidationError(Exception):
    """Raised for invalid images or filename/content type mismatches."""


class ReceiptUnsupportedFormatError(ReceiptImageValidationError):
    """Raised for unsupported extensions or extension/content mismatches."""


class ReceiptTooLargeError(Exception):
    """Raised when the image exceeds the 10 MB limit."""


class ReceiptPersistenceError(Exception):
    """Raised when receipt metadata and its audit event cannot be committed."""


async def upload_clarification_receipt(
    db: Session,
    request_id: UUID,
    original_filename: str,
    contents: bytes,
    provider: ReceiptProvider,
) -> ClarificationReceiptResponse:
    """Store one receipt and append an extraction outcome to ChaseEvent history.

    The image remains evidence when Gemini is unavailable or returns an error.
    Database failures remove the newly written image; prior uploads are untouched.
    """
    if len(contents) > MAX_UPLOAD_SIZE:
        raise ReceiptTooLargeError("The receipt image exceeds the 10 MB upload limit.")
    extension = Path(original_filename).suffix.lower().lstrip(".")
    if extension not in ALLOWED_FORMATS:
        raise ReceiptUnsupportedFormatError(
            "Unsupported file extension. Upload a JPG, JPEG, or PNG image."
        )
    _validate_image(contents, extension)

    # Check early before invoking Gemini, then end the read transaction before
    # the network request. The request is rechecked under a row lock at commit.
    if db.get(ClarificationRequest, request_id) is None:
        db.rollback()
        raise ClarificationReceiptNotFoundError("Clarification request not found.")
    db.rollback()

    RECEIPT_DIRECTORY.mkdir(parents=True, exist_ok=True)
    receipt_id = uuid4()
    stored_filename = f"{receipt_id}.{extension}"
    destination = RECEIPT_DIRECTORY / stored_filename
    with destination.open("xb") as receipt_file:
        receipt_file.write(contents)

    extraction: ReceiptExtraction | None = None
    extraction_status = "completed"
    extraction_message = "Receipt image stored and extraction completed."
    try:
        extraction = await provider.extract(contents, MEDIA_TYPES[extension])
    except ReceiptExtractionNotConfiguredError as exc:
        extraction_status = "not_configured"
        extraction_message = str(exc)
    except ReceiptExtractionError as exc:
        extraction_status = "failed"
        extraction_message = str(exc)
        logger.warning(
            "Receipt extraction failed clarification_id=%s exception_type=%s",
            request_id,
            type(exc).__name__,
        )
    except Exception as exc:
        extraction_status = "failed"
        extraction_message = "Receipt image was stored, but extraction failed."
        logger.error(
            "Receipt extraction failed clarification_id=%s exception_type=%s",
            request_id,
            type(exc).__name__,
        )

    try:
        with db.begin():
            clarification = db.scalar(
                select(ClarificationRequest)
                .where(ClarificationRequest.id == request_id)
                .with_for_update()
            )
            if clarification is None:
                raise ClarificationReceiptNotFoundError(
                    "Clarification request not found."
                )

            receipt = ClarificationReceipt(
                id=receipt_id,
                clarification_request_id=request_id,
                original_filename=Path(original_filename).name[:512],
                stored_filename=stored_filename,
                content_type=MEDIA_TYPES[extension],
                file_size=len(contents),
                extraction_status=extraction_status,
                merchant_name=extraction.merchant_name if extraction else None,
                document_type=extraction.document_type if extraction else None,
                document_number=extraction.document_number if extraction else None,
                document_date=extraction.document_date if extraction else None,
                total_amount_paise=extraction.total_amount_paise if extraction else None,
                payment_method=extraction.payment_method if extraction else None,
                payment_reference=extraction.payment_reference if extraction else None,
                confidence=(
                    extraction.confidence.model_dump(mode="json") if extraction else {}
                ),
                uncertain_fields=(
                    list(extraction.uncertain_fields)
                    if extraction
                    else [
                        "merchant_name", "document_type", "document_number",
                        "document_date", "total_amount_paise", "payment_method",
                        "payment_reference",
                    ]
                ),
                extraction_message=extraction_message,
            )
            db.add(receipt)
            clarification.status = "receipt_received"
            clarification.updated_at = datetime.now(timezone.utc)
            db.add(
                ChaseEvent(
                    id=uuid4(),
                    bank_line_id=clarification.bank_line_id,
                    clarification_request_id=clarification.id,
                    event_type="clarification_receipt_uploaded",
                    details={
                        "receipt_id": str(receipt_id),
                        "stored_filename": stored_filename,
                        "extraction_status": extraction_status,
                    },
                )
            )
            db.flush()
    except ClarificationReceiptNotFoundError:
        _remove_new_file(destination)
        db.rollback()
        raise
    except SQLAlchemyError as exc:
        db.rollback()
        _remove_new_file(destination)
        logger.error(
            "Clarification receipt persistence failed clarification_id=%s exception_type=%s",
            request_id,
            type(exc).__name__,
        )
        raise ReceiptPersistenceError(
            "Receipt metadata could not be saved."
        ) from exc
    except Exception as exc:
        db.rollback()
        _remove_new_file(destination)
        logger.error(
            "Clarification receipt transaction failed clarification_id=%s exception_type=%s",
            request_id,
            type(exc).__name__,
        )
        raise ReceiptPersistenceError(
            "Receipt metadata could not be saved."
        ) from exc

    if extraction is None:
        extraction_result = ReceiptExtractionResult(
            status=extraction_status, message=extraction_message, extraction=None
        )
    else:
        extraction_result = ReceiptExtractionResult(
            status="completed",
            message=extraction_message,
            extraction=extraction,
        )
    return ClarificationReceiptResponse(
        receipt_id=str(receipt_id),
        clarification_id=str(request_id),
        stored_filename=stored_filename,
        original_filename=Path(original_filename).name,
        content_type=MEDIA_TYPES[extension],
        file_size=len(contents),
        status="receipt_received",
        extraction=extraction_result,
        uploaded_at=receipt.uploaded_at or datetime.now(timezone.utc),
    )


def _validate_image(contents: bytes, extension: str) -> str:
    expected_format = ALLOWED_FORMATS[extension]
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(BytesIO(contents)) as image:
                detected_format = image.format
                image.verify()
    except (
        UnidentifiedImageError,
        OSError,
        ValueError,
        Image.DecompressionBombError,
        Image.DecompressionBombWarning,
    ) as exc:
        raise ReceiptImageValidationError(
            "The uploaded file is not a valid image."
        ) from exc
    if detected_format != expected_format:
        raise ReceiptUnsupportedFormatError(
            "The image content does not match its filename extension."
        )
    return detected_format


def _remove_new_file(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError as exc:
        logger.error(
            "Receipt rollback could not remove its new image exception_type=%s",
            type(exc).__name__,
        )
