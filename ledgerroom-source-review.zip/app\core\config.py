"""Environment-backed application settings."""

from functools import lru_cache
from pathlib import Path

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIRECTORY = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    """Application settings loaded from process environment or backend/.env."""

    model_config = SettingsConfigDict(
        env_file=BACKEND_DIRECTORY / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    GEMINI_API_KEY: SecretStr | None = None
    GEMINI_MODEL: str = "gemini-3.6-flash"
    RECEIPT_VERIFICATION_DATE_WINDOW_DAYS: int = Field(default=7, ge=0, le=3650)


@lru_cache
def get_settings() -> Settings:
    """Return a cached settings instance."""
    return Settings()


class DatabaseSettings(BaseSettings):
    """Database credentials loaded from process environment or backend/.env."""

    model_config = SettingsConfigDict(
        env_file=BACKEND_DIRECTORY / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    DATABASE_URL: SecretStr | None = None


@lru_cache
def get_database_settings() -> DatabaseSettings:
    """Return database settings from the same file used for app settings."""
    return DatabaseSettings()
