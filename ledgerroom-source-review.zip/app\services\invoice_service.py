"""Local image validation and storage for invoices."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path
from uuid import uuid4
import warnings

from PIL import Image, UnidentifiedImageError

MAX_UPLOAD_SIZE = 10 * 1024 * 1024
ALLOWED_FORMATS = {"jpg": "JPEG", "jpeg": "JPEG", "png": "PNG"}
INVOICE_DIRECTORY = Path(__file__).resolve().parents[3] / "data" / "invoices"


class InvoiceImageError(Exception):
    """Raised when uploaded bytes are not a valid image."""


class InvoiceFormatError(Exception):
    """Raised when the image format is unsupported or mismatches its extension."""


def _validate_image(contents: bytes, extension: str) -> None:
    expected_format = ALLOWED_FORMATS[extension]
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(BytesIO(contents)) as image:
                detected_format = image.format
                image.verify()
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError,
            Image.DecompressionBombWarning) as exc:
        raise InvoiceImageError("The uploaded file is not a valid image.") from exc

    if detected_format != expected_format:
        raise InvoiceFormatError(
            "The image content does not match its filename extension."
        )


def store_invoice(contents: bytes, original_filename: str, extension: str) -> dict[str, object]:
    """Validate an image and save its original bytes under a unique filename."""
    _validate_image(contents, extension)
    INVOICE_DIRECTORY.mkdir(parents=True, exist_ok=True)

    invoice_id = str(uuid4())
    stored_filename = f"{invoice_id}.{extension}"
    destination = INVOICE_DIRECTORY / stored_filename
    # Exclusive creation guarantees an existing file cannot be overwritten.
    with destination.open("xb") as invoice_file:
        invoice_file.write(contents)

    return {
        "invoice_id": invoice_id,
        "original_filename": Path(original_filename).name,
        "stored_filename": stored_filename,
        "file_size": len(contents),
        "upload_status": "uploaded",
    }


def list_invoices() -> list[dict[str, object]]:
    """Return metadata for the supported invoice images on disk."""
    if not INVOICE_DIRECTORY.exists():
        return []

    invoices = []
    allowed_extensions = {".jpg", ".jpeg", ".png"}
    for path in INVOICE_DIRECTORY.iterdir():
        if path.is_file() and path.suffix.lower() in allowed_extensions:
            invoices.append(
                {
                    "invoice_id": path.stem,
                    "stored_filename": path.name,
                    "file_size": path.stat().st_size,
                    "upload_status": "uploaded",
                }
            )

    return sorted(invoices, key=lambda invoice: str(invoice["stored_filename"]))


class InvoiceNotFoundError(Exception):
    """Raised when an invoice ID does not identify a stored invoice image."""


def get_invoice_path(invoice_id: str) -> Path:
    """Resolve an invoice ID to its stored image without accepting a path."""
    from uuid import UUID

    try:
        canonical_id = str(UUID(invoice_id))
    except (ValueError, TypeError, AttributeError) as exc:
        raise InvoiceNotFoundError("Invoice not found.") from exc

    invoice = next(
        (item for item in list_invoices() if item["invoice_id"] == canonical_id),
        None,
    )
    if invoice is None:
        raise InvoiceNotFoundError("Invoice not found.")

    root = INVOICE_DIRECTORY.resolve()
    stored_path = (INVOICE_DIRECTORY / str(invoice["stored_filename"])).resolve()
    if stored_path.parent != root or not stored_path.is_file():
        raise InvoiceNotFoundError("Invoice not found.")
    return stored_path


def remove_invoice_file(invoice_id: str) -> None:
    """Remove a just-created upload if its metadata transaction cannot commit."""
    get_invoice_path(invoice_id).unlink()
