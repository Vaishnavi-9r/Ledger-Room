"""Invoice upload and listing endpoints."""

import logging
from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from ..db.session import get_db
from ..models import Invoice
from ..schemas.extraction import ExtractionResponse
from ..schemas.invoice import (
    InvoiceListResponse,
    InvoiceUploadResponse,
)
from ..services.extraction_service import (
    ExtractionAuthenticationError,
    ExtractionModelUnavailableError,
    ExtractionNotConfiguredError,
    ExtractionProviderError,
    ExtractionProviderUnavailableError,
    ExtractionProvider,
    ExtractionRateLimitError,
    ExtractionTimeoutError,
    InvalidExtractionResponseError,
    extract_invoice as run_extraction,
    get_extraction_provider as create_extraction_provider,
    validate_extraction_totals,
)
from ..services.invoice_service import (
    MAX_UPLOAD_SIZE,
    InvoiceImageError,
    InvoiceFormatError,
    InvoiceNotFoundError,
    get_invoice_path,
    list_invoices,
    remove_invoice_file,
    store_invoice,
)

router = APIRouter(prefix="/api/v1/invoices", tags=["Invoices"])
logger = logging.getLogger(__name__)


def get_extraction_provider() -> ExtractionProvider:
    """Provide the configured extraction implementation to the route."""
    return create_extraction_provider()


@router.post(
    "/upload",
    response_model=InvoiceUploadResponse,
    status_code=status.HTTP_201_CREATED,
)
async def upload_invoice(
    file: UploadFile = File(...), db: Session = Depends(get_db)
) -> InvoiceUploadResponse:
    """Validate and store one JPG, JPEG, or PNG invoice image."""
    try:
        filename = file.filename or ""
        extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if extension not in {"jpg", "jpeg", "png"}:
            raise HTTPException(
                status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                detail="Unsupported file extension. Upload a JPG, JPEG, or PNG image.",
            )

        contents = await file.read(MAX_UPLOAD_SIZE + 1)
        if len(contents) > MAX_UPLOAD_SIZE:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail="The invoice image exceeds the 10 MB upload limit.",
            )

        result = store_invoice(contents, filename, extension)
    except InvoiceFormatError as exc:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=str(exc),
        ) from exc
    except InvoiceImageError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    finally:
        await file.close()

    stored_filename = str(result["stored_filename"])
    extension = stored_filename.rsplit(".", 1)[-1].lower()
    invoice = Invoice(
        id=UUID(str(result["invoice_id"])),
        original_filename=str(result["original_filename"]),
        stored_filename=stored_filename,
        content_type={"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png"}[extension],
        file_size=int(result["file_size"]),
        upload_status="uploaded",
        extraction_status="pending",
    )
    try:
        db.add(invoice)
        db.commit()
    except SQLAlchemyError as exc:
        db.rollback()
        try:
            remove_invoice_file(str(result["invoice_id"]))
        except (OSError, InvoiceNotFoundError) as cleanup_error:
            logger.error(
                "Invoice upload rollback could not remove its new image exception_type=%s",
                type(cleanup_error).__name__,
            )
        logger.error(
            "Invoice metadata insert failed exception_type=%s",
            type(exc).__name__,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Invoice metadata could not be saved to the database.",
        ) from exc

    return InvoiceUploadResponse(**result)


@router.get("/", response_model=InvoiceListResponse)
async def get_invoices() -> InvoiceListResponse:
    """List invoice images currently stored on disk."""
    return InvoiceListResponse(invoices=list_invoices())


@router.post(
    "/{invoice_id}/extract",
    response_model=ExtractionResponse,
    responses={
        404: {"description": "The invoice ID does not identify a stored invoice."},
        429: {"description": "Gemini rate or quota limit was reached."},
        502: {"description": "Gemini returned an invalid response or provider error."},
        503: {"description": "Gemini credentials, model, or service are unavailable."},
        504: {"description": "Gemini did not respond before the timeout."},
    },
)
async def extract_uploaded_invoice(
    invoice_id: str,
    provider: ExtractionProvider = Depends(get_extraction_provider),
    db: Session = Depends(get_db),
) -> ExtractionResponse | JSONResponse:
    """Attempt extraction for an uploaded invoice using the configured provider."""
    try:
        extraction = await run_extraction(invoice_id, provider)
    except InvoiceNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    except ExtractionNotConfiguredError as exc:
        body = ExtractionResponse(
            invoice_id=invoice_id,
            status="not_configured",
            message=str(exc),
            extraction=None,
        )
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content=body.model_dump(mode="json"),
        )
    except (ExtractionAuthenticationError, ExtractionModelUnavailableError) as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    except ExtractionProviderUnavailableError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    except ExtractionRateLimitError as exc:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=str(exc),
        ) from exc
    except ExtractionTimeoutError as exc:
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail=str(exc),
        ) from exc
    except InvalidExtractionResponseError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(exc),
        ) from exc
    except ExtractionProviderError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(exc),
        ) from exc

    validation_warnings = validate_extraction_totals(extraction)

    try:
        invoice = db.get(Invoice, UUID(invoice_id))
        if invoice is None:
            image_path = get_invoice_path(invoice_id)
            extension = image_path.suffix.lower()
            invoice = Invoice(
                id=UUID(invoice_id),
                original_filename=None,
                stored_filename=image_path.name,
                content_type={
                    ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg",
                    ".png": "image/png",
                }[extension],
                file_size=image_path.stat().st_size,
                upload_status="uploaded",
            )
            db.add(invoice)

        invoice.vendor_name = extraction.vendor_name
        invoice.invoice_number = extraction.invoice_number
        invoice.invoice_date = extraction.invoice_date
        invoice.due_date = extraction.due_date
        invoice.subtotal_paise = extraction.subtotal_paise
        invoice.tax_amount_paise = extraction.tax_amount_paise
        invoice.total_amount_paise = extraction.total_amount_paise
        invoice.currency = extraction.currency
        invoice.confidence = extraction.confidence.model_dump(mode="json")
        invoice.uncertain_fields = list(extraction.uncertain_fields)
        invoice.validation_warnings = validation_warnings
        invoice.extraction_status = "completed"
        invoice.extracted_at = datetime.now(timezone.utc)
        db.commit()
    except SQLAlchemyError as exc:
        db.rollback()
        logger.error(
            "Invoice extraction persistence failed exception_type=%s",
            type(exc).__name__,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Extraction completed, but invoice metadata could not be saved.",
        ) from exc

    return ExtractionResponse(
        invoice_id=invoice_id,
        status="completed",
        message=(
            "Invoice extraction completed. Confidence values are model estimates, "
            "not calibrated certainty."
        ),
        extraction=extraction,
        validation_warnings=validation_warnings,
    )
