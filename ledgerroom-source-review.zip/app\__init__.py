"""LedgerRoom FastAPI application package."""
