"""Deterministic invoice-to-bank reconciliation endpoint."""

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from ..db.session import get_db
from ..schemas.reconciliation import ReconciliationRunResponse
from ..services.reconciliation_service import run_reconciliation

router = APIRouter(prefix="/api/v1/reconciliation", tags=["Reconciliation"])
logger = logging.getLogger(__name__)


@router.post("/run", response_model=ReconciliationRunResponse)
def reconcile(db: Session = Depends(get_db)) -> ReconciliationRunResponse:
    """Evaluate invoices and persist deterministic reconciliation decisions."""
    try:
        return run_reconciliation(db)
    except SQLAlchemyError as exc:
        logger.error(
            "Reconciliation persistence failed exception_type=%s",
            type(exc).__name__,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Reconciliation results could not be saved.",
        ) from exc
